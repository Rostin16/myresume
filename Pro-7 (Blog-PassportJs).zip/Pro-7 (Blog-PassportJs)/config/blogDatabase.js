const mongoose = require("mongoose");

const db = async()=>{
  await mongoose.connect("mongodb+srv://roshnijp16:12345@cluster0.5z7b8.mongodb.net/");
  console.log("Database is Connected Successfully...");
}

module.exports = db;